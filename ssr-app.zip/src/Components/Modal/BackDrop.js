import classes from './BackDrop.module.css';

const BackDrop = () => {
    return (
        <div className={`${classes.backdrop}`} />
    )
}

export default BackDrop;