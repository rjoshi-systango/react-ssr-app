import './App.css';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import { useEffect, useState } from 'react';
import { fetchCartData, fetchFavouriteData, fetchCartProductList, productDataActions } from './Store/product-slice';
import { useDispatch, useSelector } from 'react-redux';
import Header from "./Components/Header/index";
import Advertisment from "./Components/Advertisment";
import Routes from './Routes';
import React from 'react';
import cartActions from './Redux_Thunk/cart-action-creators.es6';
import initReduxEs6 from './Redux_Thunk/init-redux.es6';
import NewApp from './NewApp';
import store from './Store';

// const store = initReduxEs6();

// console.log(store);


const App = () => {
  const dispatch = useDispatch();
  //const token = localStorage.getItem('token');
  let token = null;
  if (typeof window !== 'undefined') {
    // Perform localStorage action
   token = localStorage.getItem('token');
    // const item = localStorage.getItem('key')
  }
  const isLogin = useSelector(state => state.isLogin);
  
  useEffect(() => {
    dispatch(productDataActions.setToken({ token }));
    if (isLogin) {
      dispatch(fetchFavouriteData());
      dispatch(fetchCartProductList());

    }
  }, [dispatch, token, isLogin]);

  useEffect(() => {
    dispatch(fetchCartData());
  }, [dispatch])


  return (
    <div>
      {/* <Header />
      <Advertisment />

      <Routes /> */}
      <NewApp />
    </div>
  );
}

App.loadData = () => {
  return [
    store.dispatch(fetchCartData)
  ];
}

export default App;
